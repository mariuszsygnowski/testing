import React, { Component } from "react";
import { ApolloProvider } from "react-apollo";
import ApolloClient from "apollo-boost";
import mobiscroll from "@mobiscroll/react-lite";
import "@mobiscroll/react-lite/dist/css/mobiscroll.min.css";

import UserList from "./components/UserList";

import logo from "./acre-logo.svg";
import "./App.css";

mobiscroll.settings = {
  theme: "auto"
};

const client = new ApolloClient({
  uri: "http://localhost:4000/"
});

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      //initail selected role
      selectedRole: "ADMIN"
    };
    this.handleChangeSelectedRole = this.handleChangeSelectedRole.bind(this);
  }

  handleChangeSelectedRole(event) {
    this.setState({
      selectedRole: event.target.value
    });
  }

  render() {
    return (
      <ApolloProvider client={client}>
        <mobiscroll.Page className="vh100">
          <mobiscroll.Form className="display-grid">
            <header className="justify-content-center">
              <img
                src={logo}
                className="mbsc-img-thumbnail justify-self-center"
                alt="logo"
              />
              <div className="mbsc-padding text-align-center">
                <h1>Welcome to acre</h1>
              </div>
            </header>

            <main>
              {/********* SECTION  MOBILE VIEW *********/}
              <mobiscroll.FormGroup className="dropMenu">
                <mobiscroll.FormGroupTitle>
                  Select your role:
                </mobiscroll.FormGroupTitle>
                <mobiscroll.Dropdown
                  onChange={this.handleChangeSelectedRole}
                  icon="user4"
                  value={this.state.selectedRole}
                >
                  <option value="ADMIN">Admin</option>
                  <option value="BROKER">Broker</option>
                  <option value="ADVISOR">Advisor</option>
                </mobiscroll.Dropdown>
              </mobiscroll.FormGroup>

              {/********* SECTION  DESKTOP VIEW *********/}
              <mobiscroll.FormGroup className="segmentedMenu">
                <mobiscroll.FormGroupTitle>
                  Select your role:
                </mobiscroll.FormGroupTitle>

                <mobiscroll.Segmented
                  value="ADMIN"
                  onChange={this.handleChangeSelectedRole}
                  name="group-primary"
                  icon="fa-globe"
                  color="primary"
                  checked={this.state.selectedRole === "ADMIN"}
                >
                  Admin
                </mobiscroll.Segmented>
                <mobiscroll.Segmented
                  icon="ion-android-social-user"
                  value="BROKER"
                  onChange={this.handleChangeSelectedRole}
                  name="group-primary"
                  color="primary"
                  checked={this.state.selectedRole === "BROKER"}
                >
                  Broker
                </mobiscroll.Segmented>
                <mobiscroll.Segmented
                  value="ADVISOR"
                  onChange={this.handleChangeSelectedRole}
                  name="group-primary"
                  icon="line-user"
                  color="primary"
                  checked={this.state.selectedRole === "ADVISOR"}
                >
                  Advisor
                </mobiscroll.Segmented>
              </mobiscroll.FormGroup>

              {/********* SECTION  LIST OF USERS *********/}
              <UserList selectedRole={this.state.selectedRole} />
            </main>

            <footer className="mbsc-padding">
              Copyright 2019 | All Rights Reserved. - Mariusz Sygnowski
            </footer>
          </mobiscroll.Form>
        </mobiscroll.Page>
      </ApolloProvider>
    );
  }
}

export default App;
